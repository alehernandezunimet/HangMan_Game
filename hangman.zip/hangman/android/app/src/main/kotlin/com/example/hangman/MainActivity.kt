package com.example.hangman

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
