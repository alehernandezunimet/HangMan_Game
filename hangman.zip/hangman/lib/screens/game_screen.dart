import "package:flutter/material.dart";
import "package:shared_preferences/shared_preferences.dart";
import "../constants/constants.dart"; 

// Constante de la lógica
const int maxIntentosIncorrectos = 6;

// El Widget de la Pantalla del Juego (StatefulWidget)
class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

// La Clase de Estado 
class _GameScreenState extends State<GameScreen> {
  // Variables de Estado
  late String _palabraSecreta;
  List<String> _letrasAdivinadas = [];
  int _intentosIncorrectos = 0;

  // Variables para la persistencia
  late SharedPreferences _prefs;
  int _conteoPartidasSesion = 0;
  int _totalGanadas = 0;
  int _totalJugadas = 0;

  // Lógica de estado final
  // Función: Verifica si el jugador ganó
  bool _siGano() {
    return !_obtenerPalabraOculta().contains("_");
  }

  // Función: Verifica si el jugador perdió
  bool _siPerdio() {
    return _intentosIncorrectos >= maxIntentosIncorrectos;
  }
  
  // Ciclo de vida: Inicializa estado y carga datos
  @override
  void initState() {
    super.initState();
    _seleccionarNuevaPalabra(); // Inicialización de palabra secreta
    _cargarPuntuaciones(); // Carga de historial de puntuaciones
  }

  // --- PERSISTENCIA ---
  // Función: Carga el historial de puntuaciones
  void _cargarPuntuaciones() async {
    _prefs = await SharedPreferences.getInstance();
    setState(() {
      _totalGanadas = _prefs.getInt("gamesWon") ?? 0;
      _totalJugadas = _prefs.getInt("gamesPlayed") ?? 0;
    });
  }

  // Función: Guarda las puntuaciones actuales
  void _guardarPuntuaciones() {
    _prefs.setInt("gamesWon", _totalGanadas);
    _prefs.setInt("gamesPlayed", _totalJugadas);
  }

  // Función: Actualiza los contadores al final del juego
  void _manejarFinDeJuego(bool siGano) {
    if (siGano) {
      _totalGanadas++;
    }
    _totalJugadas++;
    _guardarPuntuaciones();
  }

  // LÓGICA DEL JUEGO 
  // Selecciona una palabra aleatoria de la listaPalabras
  void _seleccionarNuevaPalabra() {
    // Creación de una COPIA mutable de la lista para barajar.
    final List<String> mutableWordList = List.from(listaPalabras);
    
    // Barajar la lista mutable.
    mutableWordList.shuffle(); 
    
    // Asignación de la palabra secreta.
    _palabraSecreta = mutableWordList.first;
  }
  
  // Restablece el estado del juego para una nueva partida
  void _reiniciarJuego() {
    setState(() {
      _conteoPartidasSesion++; // Incremento del contador de sesión
      _seleccionarNuevaPalabra();
      _letrasAdivinadas = [];
      _intentosIncorrectos = 0;
    });
  }

  // Maneja el intento de una letra
  void _adivinarLetra(String letra) {
    // Evita intentos si el juego terminó.
    if (_siPerdio() || _siGano()) return;

    setState(() {
      final letraNormalizada = letra.toUpperCase();

      // Comprobación de letra repetida.
      if (_letrasAdivinadas.contains(letraNormalizada)) {
        return;
      }

      _letrasAdivinadas.add(letraNormalizada);

      // Lógica para intento incorrecto.
      if (!_palabraSecreta.contains(letraNormalizada)) {
        _intentosIncorrectos++;
      }

      // Lógica de final de juego.
      final bool siGano = _siGano();
      final bool siPerdio = _siPerdio();
      
      if (siGano) {
        _manejarFinDeJuego(true);
      } else if (siPerdio) {
        _manejarFinDeJuego(false);
      }
    });
  }

  // Genera la palabra con guiones bajos
  String _obtenerPalabraOculta() {
    String display = "";
    for (int i = 0; i < _palabraSecreta.length; i++) {
      String char = _palabraSecreta[i];
      if (_letrasAdivinadas.contains(char)) {
        display += "$char ";
      } else {
        display += "_ ";
      }
    }
    return display.trim();
  }

  // WIDGET VISUAL 

  // Muñeco del Ahorcado
  String _obtenerArteAhorcado() {
    const List<String> hangmanSteps = [
      // 0 fallos
      """
  +---+
  |   |
      |
      |
      |
      |
=========""",
      // 1 fallo
      """
  +---+
  |   |
  O   |
      |
      |
      |
=========""",
      // 2 fallos
      """
  +---+
  |   |
  O   |
  |   |
      |
      |
=========""",
      // 3 fallos
      """
  +---+
  |   |
  O   |
 /|   |
      |
      |
=========""",
      // 4 fallos
      """
  +---+
  |   |
  O   |
 /|\\  |
      |
      |
=========""",
      // 5 fallos
      """
  +---+
  |   |
  O   |
 /|\\  |
 /    |
      |
=========""",
      // 6 fallos (Perdió)
      """
  +---+
  |   |
  O   |
 /|\\  |
 / \\  |
      |
=========""",
    ];
    // Mapeo de fallos al índice del muñeco.
    final index = _intentosIncorrectos.clamp(0, hangmanSteps.length - 1);
    return hangmanSteps[index];
  }


  // WIDGET BUILD 
  @override
  Widget build(BuildContext context) {
    // Declaración de estado del juego usando las funciones en español
    final siGano = _siGano();
    final siPerdio = _siPerdio();
    final mensajeEstadoJuego = siGano
        ? "¡GANASTE!"
        : siPerdio
            // Uso de la variable renombrada
            ? "¡PERDISTE! La palabra era: $_palabraSecreta"
            : "";

    return Scaffold(
      appBar: AppBar(
        title: const Text("Juego del Ahorcado "),
        centerTitle: true,
        backgroundColor: Colors.blueGrey[900],
      ),
      body: SingleChildScrollView( // Contenedor desplazable (Responsivo)
        child: Center(
          child: Column( // Contenedor vertical principal
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const SizedBox(height: 20),

              // Indicadores de Puntuación (Extra)
              Text(
                // Uso de las variables renombradas
                "Partidas en la sesión: $_conteoPartidasSesion",
                style: const TextStyle(fontSize: 14, color: Colors.white70),
              ),
              Text(
                "Histórico - Ganadas: $_totalGanadas / Jugadas: $_totalJugadas",
                style: const TextStyle(fontSize: 14, color: Colors.white70),
              ),
              const SizedBox(height: 10),
              
              // Muñeco del Ahorcado (Visual)
              Text(
                _obtenerArteAhorcado(), // Función renombrada
                style: const TextStyle(
                    fontFamily: "monospace",
                    fontSize: 14,
                    color: Colors.white),
              ),

              const SizedBox(height: 20),
              
              // Indicador de Intentos Restantes
              Text(
                // Uso de variables renombradas
                "Intentos restantes: ${maxIntentosIncorrectos - _intentosIncorrectos}",
                style: TextStyle(fontSize: 20, color: (maxIntentosIncorrectos - _intentosIncorrectos) <= 2 ? Colors.redAccent : Colors.yellowAccent),
              ),

              const SizedBox(height: 30),

              // Palabra Oculta
              Text(
                _obtenerPalabraOculta(), // Función renombrada
                style: const TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 8,
                    color: Colors.white),
              ),

              const SizedBox(height: 30),

              // Bloque Condicional (Mensaje de Fin de Juego o Teclado)
              if (siGano || siPerdio) // Condición renombrada
                Padding(
                  padding: const EdgeInsets.only(bottom: 20.0),
                  child: Column(
                    children: [
                      // Mensaje de Ganador/Perdedor
                      Text(
                        mensajeEstadoJuego,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: siGano ? Colors.greenAccent : Colors.redAccent,
                        ),
                      ),
                      const SizedBox(height: 15),
                      // Botón de Reinicio
                      ElevatedButton(
                        onPressed: _reiniciarJuego, // Función renombrada
                        child: const Text("Jugar de Nuevo", style: TextStyle(fontSize: 18)),
                      ),
                    ],
                  ),
                )
              else 
                // Teclado Funcional (Widget Wrap - Responsivo)
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Wrap(
                    spacing: 8.0, 
                    runSpacing: 8.0, 
                    children: "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                        .split("")
                        .map((letter) {
                      final bool isGuessed = _letrasAdivinadas.contains(letter); // Variable renombrada
                      return ElevatedButton(
                        onPressed: isGuessed ? null : () => _adivinarLetra(letter), // Función renombrada
                        style: ElevatedButton.styleFrom(
                          minimumSize: const Size(40, 40),
                          backgroundColor: isGuessed
                              // Uso de variables renombradas
                              ? (_palabraSecreta.contains(letter) ? Colors.green[400] : Colors.red[400])
                              : Colors.blueGrey[700],
                          foregroundColor: Colors.white,
                        ),
                        child: Text(letter, style: const TextStyle(fontSize: 16)),
                      );
                    }).toList(),
                  ),
                ),

              // Indicador de letras ya usadas
              Text(
                "Letras usadas: ${_letrasAdivinadas.join(", ")}", // Variable renombrada
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16, color: Colors.grey),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}