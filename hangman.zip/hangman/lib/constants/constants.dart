final  List<String> listaPalabras = [
  'FLUTTER',
  'DART',
  'WIDGET',
  'SCAFFOLD',
  'BUILD',
  'STATEFUL',
  'ANDROID',
  'APPLE',
  'CODIGO',
];